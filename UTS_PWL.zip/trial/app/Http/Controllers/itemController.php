<?php

namespace App\Http\Controllers;

use App\Models\item;
use Illuminate\Http\Request;

class itemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $key = $request->search;
        $item = item::where('name','LIKE',"%".$key."%")
        ->orwhere('category','LIKE' ,"%".$key."%")
        ->orwhere('code','LIKE' ,"%".$key."%")->get();
        return view('item.index',compact('item'));
   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */ 
    public function create()
    {
        return view('item.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'code'=>'required',
            'name'=>'required',
            'category'=>'required',
            'price'=>'required',
            'qty'=>'required',
        ]);
        
        $item = new item;
        $item -> code = $request -> code;
        $item -> name = $request -> name;
        $item -> category = $request -> category;
        $item -> price = $request -> price;
        $item -> qty = $request -> qty;
        $item -> save();

        return to_route('item.index')->with('success','Data succesfully added.');
    } 

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('item.edit')->with([
            'item' => item::find($id),
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request -> validate([
            'code'=>'required',
            'name'=>'required',
            'category'=>'required',
            'price'=>'required',
            'qty'=>'required',
        ]);
        
        $item = item::find($id);
        $item -> code = $request -> code;
        $item -> name = $request -> name;
        $item -> category = $request -> category;
        $item -> price = $request -> price;
        $item -> qty = $request -> qty;
        $item -> save();

        return to_route('item.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = item::find($id);
        $item->delete();

        return to_route('item.index');
    }
}

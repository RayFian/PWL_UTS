<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inventory Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Inventory Management</h1>
        <div class="mb-2">
            <form method="GET" action="{{route('item.index')}}">
                <div class="input-group flex-nowrap">
                    <button class="input-group-text" id="addon-wrapping">Search</button>
                    <input type="text" class="form-control" placeholder="Item Name" aria-label="Username" aria-describedby="addon-wrapping" name="search">
                </div>
            </form>
        </div>
        <a href="{{route('item.create')}}" class="btn btn-primary mb-1">Add Item</a>
        <div class="card">
            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>id</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Option</th>
                    </thead>
                    <tbody>
                        @foreach ($item as $no => $hasil)
                            <tr>
                                <th>{{$no+1}}</th>
                                <td>{{$hasil -> code}}</td>
                                <td>{{$hasil -> name}}</td>
                                <td>{{$hasil -> category}}</td>
                                <td>{{$hasil -> price}}</td>
                                <td>{{$hasil -> qty}}</td>
                                <td>
                                    
                                    
                                    <form action="{{route('item.destroy',$hasil->id)}}" method="POST">

                                        @method('DELETE')
                                        @csrf
                                        <a href="{{route('item.edit',$hasil->id)}}" class="btn btn-success btn-sm">Edit</a>
                                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
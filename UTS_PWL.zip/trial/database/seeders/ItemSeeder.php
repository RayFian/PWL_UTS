<?php

namespace Database\Seeders;
namespace App\Models;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
namespace Database\Seeders;

class itemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('item') -> insert([
            'code' => 'ELC001',
            'item' => 'Samsung A99 10G',
            'category' => 'Elektronik',
            'price' => '1200000',
            'qty' => '10'
        ]);

        DB::table('item') -> insert([
            'code' => 'ELC002',
            'item' => 'Redmi Note 4',
            'category' => 'Elektronik',
            'price' => '1000000',
            'qty' => '2'
        ]);

        DB::table('item') -> insert([
            'code' => 'ELC003',
            'item' => 'Macbook Air 1',
            'category' => 'Elektronik',
            'price' => '8000000',
            'qty' => '7'
        ]);

        DB::table('item') -> insert([
            'code' => 'ELC004',
            'item' => 'Xiaomi X2',
            'category' => 'Elektronik',
            'price' => '3000000',
            'qty' => '22'
        ]);

        DB::table('item') -> insert([
            'code' => 'ELC005',
            'item' => 'VR Cloud R3',
            'category' => 'Elektronik',
            'price' => '9500000',
            'qty' => '4'
        ]);

        DB::table('item') -> insert([
            'code' => 'FOD001',
            'item' => 'Dry Ice Tortilla',
            'category' => 'Makanan',
            'price' => '9000',
            'qty' => '10'
        ]);

        DB::table('item') -> insert([
            'code' => 'FOD002',
            'item' => 'Burning Meat Skewer',
            'category' => 'Makanan',
            'price' => '10000',
            'qty' => '22'
        ]);

        DB::table('item') -> insert([
            'code' => 'FOD003',
            'item' => 'Pecel Malang',
            'category' => 'Makanan',
            'price' => '5000',
            'qty' => '2'
        ]);

        DB::table('item') -> insert([
            'code' => 'FOD004',
            'item' => 'Mixed vegetables with peanut sauce',
            'category' => 'Makanan',
            'price' => '15000',
            'qty' => '21'
        ]);

        DB::table('item') -> insert([
            'code' => 'FOD005',
            'item' => 'Edible Charcoal',
            'category' => 'Makanan',
            'price' => '2000',
            'qty' => '210'
        ]);

        DB::table('item') -> insert([
            'code' => 'CLT001',
            'item' => 'Levis T-Shirt',
            'category' => 'Pakaian',
            'price' => '200000',
            'qty' => '33'
        ]);

        DB::table('item') -> insert([
            'code' => 'CLT002',
            'item' => 'Daemonic Jeans',
            'category' => 'Pakaian',
            'price' => '100000',
            'qty' => '22'
        ]);

        DB::table('item') -> insert([
            'code' => 'CLT003',
            'item' => 'Quickbronze Hat',
            'category' => 'Pakaian',
            'price' => '85000',
            'qty' => '10'
        ]);

        DB::table('item') -> insert([
            'code' => 'CLT004',
            'item' => 'Cobra Scraf',
            'category' => 'Pakaian',
            'price' => '50000',
            'qty' => '12'
        ]);

        DB::table('item') -> insert([
            'code' => 'CLT005',
            'item' => 'Nedava Shorties',
            'category' => 'Pakaian',
            'price' => '120000',
            'qty' => '2'
        ]);

        DB::table('item') -> insert([
            'code' => 'BOK001',
            'item' => 'Order of blue bird',
            'category' => 'Buku',
            'price' => '150000',
            'qty' => '30'
        ]);

        DB::table('item') -> insert([
            'code' => 'BOK002',
            'item' => 'Journey to the north',
            'category' => 'Buku',
            'price' => '80000',
            'qty' => '1'
        ]);

        DB::table('item') -> insert([
            'code' => 'BOK003',
            'item' => 'Reincarnated as a wood',
            'category' => 'Buku',
            'price' => '100000',
            'qty' => '12'
        ]);

        DB::table('item') -> insert([
            'code' => 'BOK004',
            'item' => 'Human meterpede',
            'category' => 'Buku',
            'price' => '200000',
            'qty' => '2'
        ]);

        DB::table('item') -> insert([
            'code' => 'BOK005',
            'item' => 'Shadow shaman',
            'category' => 'Buku',
            'price' => '90000',
            'qty' => '10'
        ]);
    }
}

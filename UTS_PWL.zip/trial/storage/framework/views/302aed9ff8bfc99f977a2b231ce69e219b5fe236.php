<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inventory Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Inventory Management</h1>
        <div class="mb-2">
            <form method="GET" action="<?php echo e(route('item.index')); ?>">
                <div class="input-group flex-nowrap">
                    <button class="input-group-text" id="addon-wrapping">Search</button>
                    <input type="text" class="form-control" placeholder="Item Name" aria-label="Username" aria-describedby="addon-wrapping" name="search">
                </div>
            </form>
        </div>
        <a href="<?php echo e(route('item.create')); ?>" class="btn btn-primary mb-1">Add Item</a>
        <div class="card">
            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>id</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Option</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($no+1); ?></th>
                                <td><?php echo e($hasil -> code); ?></td>
                                <td><?php echo e($hasil -> name); ?></td>
                                <td><?php echo e($hasil -> category); ?></td>
                                <td><?php echo e($hasil -> price); ?></td>
                                <td><?php echo e($hasil -> qty); ?></td>
                                <td>
                                    
                                    
                                    <form action="<?php echo e(route('item.destroy',$hasil->id)); ?>" method="POST">

                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <a href="<?php echo e(route('item.edit',$hasil->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH R:\KAMPUS\POLINEMA\Laravel\trial\resources\views/item/index.blade.php ENDPATH**/ ?>